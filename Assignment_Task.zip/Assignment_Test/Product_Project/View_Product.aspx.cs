﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Web.UI.WebControls;

public partial class View_Product : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    

    protected void Download_Click(object sender, EventArgs e)
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        using (StringWriter sw = new StringWriter())
        {
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            //To Export all pages
            slnogrd.AllowPaging = false;
            //this.BindData();

            // GridView1.HeaderRow.BackColor = Color.White;
            foreach (TableCell cell in slnogrd.HeaderRow.Cells)
            {
                cell.BackColor = slnogrd.HeaderStyle.BackColor;
            }
            foreach (GridViewRow row in slnogrd.Rows)
            {
                // row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = slnogrd.AlternatingRowStyle.BackColor;
                    }
                    else
                    {
                        cell.BackColor = slnogrd.RowStyle.BackColor;
                    }
                    cell.CssClass = "textmode";
                }
            }

            slnogrd.RenderControl(hw);

            //style to format numbers to string
            string style = @"<style> .textmode { } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */
    }
    protected void Getproductdetails_Click1(object sender, EventArgs e)
    {
        if (producttxt.Text == "")
        {
            Response.Write("<script> alert('Please enter Product No'); </script>");
            return;
        }
        else
        {
            conn.Open();
            string cmdstr = "select * from Product where ProductNo='" + producttxt.Text + "'  ";
            SqlCommand cmd = new SqlCommand(cmdstr, conn);
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            slnogrd.DataSource = dt;
            slnogrd.DataBind();
            conn.Close();
        }
    }
    protected void Back_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home_Page.aspx");
        return;
    }
}