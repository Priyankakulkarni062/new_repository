﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Data.SqlClient;

public partial class AddNewProduct : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void additemtxt_Click(object sender, EventArgs e)
    {
        if (productnotxt.Text == "")
        {
            Response.Write("<script> alert('Please enter Product No.'); </script>");
            return;
        }
        if (Productnametxt.Text == "")
        {
            Response.Write("<script> alert('Please enter Product Name.'); </script>");
            return;
        }
        if (Productdescriptiontxt.Text == "")
        {
            Response.Write("<script> alert('Please enter Product description.'); </script>");
            return;
        }
        if (Pricetxt.Text == "")
        {
            Response.Write("<script> alert('Please enter Product price.'); </script>");
            return;
        }
        if (Contactpersontxt.Text == "")
        {
            Response.Write("<script> alert('Please enter Contact person.'); </script>");
            return;
        }
        if (Emailtxt.Text == "")
        {
            Response.Write("<script> alert('Please enter Email.'); </script>");
            return;
        }
        conn.Close();
        conn.Open();
        SqlCommand cmd1 = new SqlCommand("SP_ProductMaster", conn);
        cmd1.CommandType = CommandType.StoredProcedure;
        cmd1.CommandText = "SP_ProductMaster";
        cmd1.Parameters.AddWithValue("@Flag", "AddNewProduct");
        cmd1.Parameters.AddWithValue("@ProductNo", productnotxt.Text);
        cmd1.Parameters.AddWithValue("@ProductName", Productnametxt.Text);
        cmd1.Parameters.AddWithValue("@ProductDescription", Productdescriptiontxt.Text);
        cmd1.Parameters.AddWithValue("@Price", Pricetxt.Text);
        cmd1.Parameters.AddWithValue("@ContactPerson", Contactpersontxt.Text);
        cmd1.Parameters.AddWithValue("@Email", Emailtxt.Text);
        cmd1.ExecuteNonQuery();
        conn.Close();
        Response.Write("<script> alert('You have successfully added new product details'); </script>");
    }
    protected void Back_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home_Page.aspx");
        return;
    }
}