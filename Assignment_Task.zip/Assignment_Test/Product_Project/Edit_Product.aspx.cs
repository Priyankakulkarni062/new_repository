﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Data.SqlClient;

public partial class Edit_Product : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void EDITitemtxt_Click(object sender, EventArgs e)
    {
        conn.Close();
        conn.Open();
        SqlCommand cmd1 = new SqlCommand("SP_ProductMaster", conn);
        cmd1.CommandType = CommandType.StoredProcedure;
        cmd1.CommandText = "SP_ProductMaster";
        cmd1.Parameters.AddWithValue("@Flag", "Productupdate");
        cmd1.Parameters.AddWithValue("@ProductNo", productnotxt.Text);
        cmd1.Parameters.AddWithValue("@ProductName", Productnametxt.Text);
        cmd1.Parameters.AddWithValue("@ProductDescription", Productdescriptiontxt.Text);
        cmd1.Parameters.AddWithValue("@Price", Pricetxt.Text);
        cmd1.Parameters.AddWithValue("@ContactPerson", Contactpersontxt.Text);
        cmd1.Parameters.AddWithValue("@Email", Emailtxt.Text);
        cmd1.ExecuteNonQuery();
        conn.Close();
        Response.Write("<script> alert('You have successfully Edited product details'); </script>");

    }


    protected void Getproductdetails_Click(object sender, EventArgs e)
    {
        if (productnotxt.Text == "")
        {
            Response.Write("<script> alert('Please enter Product No'); </script>");
            return;
        }
        else
        {
            conn.Close();
            conn.Open();
            SqlCommand cmd = new SqlCommand("SP_ProductMaster", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "SP_ProductMaster";
            cmd.Parameters.AddWithValue("@Flag", "Getproductdetails");
            cmd.Parameters.AddWithValue("@ProductNo", productnotxt.Text);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Productnametxt.Text = (dr["ProductName"].ToString());
                Productdescriptiontxt.Text = (dr["ProductDescription"].ToString());
                Pricetxt.Text = (dr["Price"].ToString());
                Contactpersontxt.Text = (dr["ContactPerson"].ToString());
                Emailtxt.Text = (dr["Email"].ToString());

            }
        }
    }
    protected void Back_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home_Page.aspx");
        return;
    }
}