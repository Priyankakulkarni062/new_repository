﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Home_Page : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Addproduct_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddNewProduct.aspx");
        return;
    }

    protected void Editproduct_Click(object sender, EventArgs e)
    {
        Response.Redirect("Edit_Product.aspx");
        return;
    }

    protected void Deleteproduct_Click(object sender, EventArgs e)
    {
        Response.Redirect("Delete_Product.aspx");
        return;
    }

    protected void Viewproduct_Click(object sender, EventArgs e)
    {
        Response.Redirect("View_Product.aspx");
        return;
    }
}