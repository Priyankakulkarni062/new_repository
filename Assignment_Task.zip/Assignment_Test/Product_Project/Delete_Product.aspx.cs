﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Data.SqlClient;

public partial class Delete_Product : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void deleteproductitem_Click(object sender, EventArgs e)
    {
        conn.Close();
        conn.Open();
        SqlCommand cmd1 = new SqlCommand("SP_ProductMaster", conn);
        cmd1.CommandType = CommandType.StoredProcedure;
        cmd1.CommandText = "SP_ProductMaster";
        cmd1.Parameters.AddWithValue("@Flag", "Deleteproduct");
        cmd1.Parameters.AddWithValue("@ProductNo", productnotxt.Text);
        cmd1.ExecuteNonQuery();
        conn.Close();
        Response.Write("<script> alert('You have successfully Deleted product details'); </script>");
    }
    protected void Back_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home_Page.aspx");
        return;
    }
}